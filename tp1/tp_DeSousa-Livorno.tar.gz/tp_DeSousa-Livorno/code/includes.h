#ifndef __INCLUDES_H__
#define __INCLUDES_H__

#include <cmath>
#include <iostream>
#include <cstdlib>
#include <cstdio>
#include <cstring>

using namespace std;

#define ullInt unsigned long long
#define llInt  long long

#endif
